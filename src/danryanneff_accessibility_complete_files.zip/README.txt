DanRyanNeff.com accessibility toolbar - complete replacement files

Created for the current GitHub repository:
https://github.com/danryanneffreads/danryanneff-com

WHAT THIS ADDS
- A small two-button toolbar fixed at the middle-right of all pages.
- A black-on-white high-contrast setting. This does not replace or change the existing dark/light toggle.
- Text size steps: 100%, 125%, 150%, 175%, 200%, and back to 100%.
- Visitor preferences saved in the browser.
- Keyboard focus states and screen reader labels.

INSTALLATION (NO CODE INSERTIONS)
1. Extract this ZIP.
2. In VS Code, open your local danryanneff-com repository folder.
3. Copy the ZIP's src/layouts/BaseLayout.astro over the existing src/layouts/BaseLayout.astro.
4. Copy the ZIP's src/components/AccessibilityToolbar.astro into your existing src/components folder.
5. Run npm run dev and view the site locally. Try both toolbar controls, existing dark mode, and a narrow browser window.
6. When satisfied, commit and push the two files using your usual GitHub workflow.

DO NOT copy the ZIP's src folder itself over your whole project's src folder.
Only the two files above are intended to be copied or replaced.

This package was prepared after reading BaseLayout.astro, DarkModeToggle.astro,
global.css, Header.astro, and the site's Tailwind configuration from GitHub.
The GitHub repository was not modified.

Text resizing scales CSS rem units; unusual fixed-pixel content may not resize.
As with any accessibility overlay, these controls supplement, not replace,
accessible website markup and manual testing.
